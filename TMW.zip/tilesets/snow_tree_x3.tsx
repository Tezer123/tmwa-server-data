<?xml version="1.0" encoding="UTF-8"?>
<tileset name="snow_tree_x3" tilewidth="64" tileheight="96">
 <image source="../graphics/tiles/snow_tree_x3.png" width="256" height="96"/>
</tileset>
