<?xml version="1.0" encoding="UTF-8"?>
<tileset name="snow_village_x4" tilewidth="32" tileheight="128">
 <image source="../graphics/tiles/snow_village_x4.png" width="320" height="128"/>
</tileset>
