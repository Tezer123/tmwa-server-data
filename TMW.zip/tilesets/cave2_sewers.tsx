<?xml version="1.0" encoding="UTF-8"?>
<tileset name="cave2_sewers" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/cave2_sewers.png" width="512" height="288"/>
</tileset>
