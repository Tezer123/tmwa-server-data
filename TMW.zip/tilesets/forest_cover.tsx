<?xml version="1.0" encoding="UTF-8"?>
<tileset name="forest_cover" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/forest_cover.png" width="320" height="320"/>
</tileset>
