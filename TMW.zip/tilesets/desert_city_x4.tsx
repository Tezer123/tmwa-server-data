<?xml version="1.0" encoding="UTF-8"?>
<tileset name="desert_city_x4" tilewidth="32" tileheight="128">
 <image source="../graphics/tiles/desert_city_x4.png" width="256" height="128"/>
</tileset>
